<!DOCTYPE html>
<html lang="en-US">
	<head>
		<meta charset="utf-8">
	</head>
	<body>
		<h2>Forget  Password</h2>
		<p>{{ $user->name }}</p>
	</body>
</html>

