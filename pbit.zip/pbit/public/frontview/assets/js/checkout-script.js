$(document).ready(function(){
       $("#mycheckout").click(function(){        
        $("#pbit-forget-pass-sect").hide();
        $(".signup-section").hide();
        $("#myModal").modal();
        $(".login-section").show();
    });  


});